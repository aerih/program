clear
t = zeros(1000,1);
error = zeros(1000,1);
deta_f = zeros(1000,1);
